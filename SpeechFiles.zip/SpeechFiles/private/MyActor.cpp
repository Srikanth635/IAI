// Fill out your copyright notice in the Description page of Project Settings.


#include "MyActor.h"

// Sets default values
AMyActor::AMyActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void AMyActor::BeginPlay()
{
	Super::BeginPlay();
	whisperParams.n_threads = n_threads;
	whisperParams.capture_id = capture_id;
	whisperParams.step_ms = step_ms;
	whisperParams.length_ms = length_ms;
	whisperParams.keep_ms = keep_ms;
	whisperParams.capture_id = capture_id;
	whisperParams.max_tokens = max_tokens;
	whisperParams.audio_ctx = audio_ctx;
	whisperParams.vad_thold = vad_thold;
	whisperParams.freq_thold = freq_thold;
	whisperParams.speed_up = speed_up;
	whisperParams.translate = translate;
	whisperParams.print_special = print_special;
	whisperParams.no_context = no_context;
	whisperParams.no_timestamps = no_timestamps;
	//whisperParams.language = language;
	//whisperParams.model = model;
	//whisperParams.fname_out = fname_out;

	listenerThread = new FMySpeechWorker();
	bool threadSuccess = listenerThread->StartThread(this,whisperParams);
	
}

// Called every frame
void AMyActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}


bool AMyActor::Shutdown()
{
	if (listenerThread != NULL) {
		listenerThread->ShutDown();
		listenerThread = NULL;
		return true;
	}
	else {
		return false;
	}
}
