// Fill out your copyright notice in the Description page of Project Settings.

#include "MySpeechActor.h"




// Sets default values
AMySpeechActor::AMySpeechActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	

}

// Called when the game starts or when spawned
void AMySpeechActor::BeginPlay()
{
	Super::BeginPlay();

	params.n_threads = n_threads;
	params.step_ms = step_ms;
	params.length_ms = length_ms;
	params.keep_ms = keep_ms;
	params.capture_id = capture_id;
	params.max_tokens = max_tokens;
	params.audio_ctx = audio_ctx;

	params.vad_thold = vad_thold;
	params.freq_thold = freq_thold;

	params.speed_up = speed_up;
	params.translate = translate;
	params.print_special = print_special;
	params.no_context = no_context;
	params.no_timestamps = no_timestamps;

	params.language = language;
	params.model = model;
	params.fname_out = fname_out;

	listenerThread = new FMySpeechWorker();
	bool threadSuccess = listenerThread->StartThread(this, params);
	
}

// Called every frame
void AMySpeechActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}



bool AMySpeechActor::Shutdown()
{
	if (listenerThread != NULL) {
		listenerThread->ShutDown();
		listenerThread = NULL;
		return true;
	}
	else {
		return false;
	}
}
