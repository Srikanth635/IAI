// Copyright 2017-present, Institute for Artificial Intelligence - University of Bremen

#pragma once

#include "CoreMinimal.h"
#include "Engine/StaticMeshActor.h"
#include "SLLookAtTarget.generated.h"

/**
 * 
 */
UCLASS()
class ASLLookAtTarget : public AStaticMeshActor
{
	GENERATED_BODY()
	
};
