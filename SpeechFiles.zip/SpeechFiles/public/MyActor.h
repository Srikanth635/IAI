// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "MySpeechWorker.h"
#include "SpeechRecognition.h"
#include "MyActor.generated.h"

UCLASS(BlueprintType, Blueprintable)
class SPEECHRECOGNITION_API AMyActor : public AActor
{
	GENERATED_BODY()

		FMySpeechWorker* listenerThread;

public:
	// Sets default values for this actor's properties
	AMyActor();
	FWhisperParams whisperParams;
protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	UFUNCTION(BlueprintCallable, Category = "Audio", meta = (DisplayName = "Shutdown", Keywords = "Speech Recognition Shutdown"))
		bool Shutdown();

	//FWhisper_params params;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, category = "Whisper")
		int32 n_threads = std::min(4, (int)std::thread::hardware_concurrency());

	UPROPERTY(EditAnywhere, BlueprintReadWrite, category = "Whisper")
		int32 step_ms = 3000;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, category = "Whisper")
		int32 length_ms = 10000;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, category = "Whisper")
		int32 keep_ms = 200;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, category = "Whisper")
		int32 capture_id = -1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, category = "Whisper")
		int32 max_tokens = 32;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, category = "Whisper")
		int32 audio_ctx = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, category = "Whisper")
		float vad_thold = 0.6f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, category = "Whisper")
		float freq_thold = 100.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, category = "Whisper")
		bool speed_up = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, category = "Whisper")
		bool translate = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, category = "Whisper")
		bool print_special = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, category = "Whisper")
		bool no_context = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, category = "Whisper")
		bool no_timestamps = false;

	//UPROPERTY(EditAnywhere, BlueprintReadWrite, category = "Whisper")
		//FString language = "en";

	//UPROPERTY(EditAnywhere, BlueprintReadWrite, category = "Whisper")
		//FString model = "S:/POOL/Unreal/IAI_Abhijit/Sphinx_UE4_Demo/Content/model/ggml-base.en.bin";

	//UPROPERTY(EditAnywhere, BlueprintReadWrite, category = "Whisper")
		//FString fname_out;

};
