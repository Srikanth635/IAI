// Copyright 2017-present, Institute for Artificial Intelligence - University of Bremen


#include "SLScreenPrinter.h"

// Sets default values
ASLScreenPrinter::ASLScreenPrinter()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void ASLScreenPrinter::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void ASLScreenPrinter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

