// Fill out your copyright notice in the Description page of Project Settings.

#include "MySpeechActor.h"




// Sets default values
AMySpeechActor::AMySpeechActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	UE_LOG(LogTemp, Warning, TEXT("MAXIMUM THREADS : %d"), (int)std::thread::hardware_concurrency());
	

}

// Called when the game starts or when spawned
void AMySpeechActor::BeginPlay()
{
	Super::BeginPlay();
	whisperParams.n_threads = n_threads;
	whisperParams.prompt_ms = prompt_ms;
	whisperParams.command_ms = command_ms;
	whisperParams.capture_id = capture_id;
	whisperParams.max_tokens = max_tokens;
	whisperParams.audio_ctx = audio_ctx;
	whisperParams.vad_thold = vad_thold;
	whisperParams.freq_thold = freq_thold;
	whisperParams.speed_up = speed_up;
	whisperParams.translate = translate;
	whisperParams.print_special = print_special;
	whisperParams.print_energy = print_energy;
	whisperParams.no_timestamps = no_timestamps;
	

	listenerThread = new FMySpeechWorker();
	bool threadSuccess = listenerThread->StartThread(this, whisperParams);
	
}

// Called every frame
void AMySpeechActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void AMySpeechActor::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Shutdown();
	Super::EndPlay(EndPlayReason);
}

bool AMySpeechActor::Shutdown()
{
	if (listenerThread != NULL) {
		listenerThread->ShutDown();
		listenerThread = NULL;
		return true;
	}
	else {
		return false;
	}
}
