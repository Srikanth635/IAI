#pragma once

#include "whisper/whisper.h"
#include <SDL2/SDL.h>
#include <SDL2/SDL_audio.h>
#include "SpeechRecognition.h"

#include <atomic>
#include <cstdio>
#include <stdio.h>
#include <time.h>
#include <regex>
#include <string>
#include <set>
#include <map>
#include <fstream>
#include <iostream>
#include <sstream>
#include <locale>
#include <cstdio>
#include <vector>
#include <utility>
#include <thread>
#include <mutex>
#include <cassert>


//General Log
//DECLARE_LOG_CATEGORY_EXTERN(SpeechRecognitionPlugin, Log, All);
//#define SENSCR_SHIFT 10

class audio_async {
public:
	audio_async(int len_ms);
	~audio_async();
	bool init(int capture_id, int sample_rate);
	// start capturing audio via the provided SDL callback
	// keep last len_ms seconds of audio in a circular buffer
	bool resume();
	bool pause();
	bool clear();

	// callback to be called by SDL
	void callback(uint8_t* stream, int len);

	// get audio data from the circular buffer
	void get(int ms, std::vector<float>& audio);
private:
	SDL_AudioDeviceID m_dev_id_in = 0;
	

	int m_len_ms = 0;
	int m_sample_rate = 0;

	std::atomic_bool m_running;
	std::mutex       m_mutex;

	std::vector<float> m_audio;
	std::vector<float> m_audio_new;
	size_t             m_audio_pos = 0;
	size_t             m_audio_len = 0;
};

class AMySpeechActor;


class FMySpeechWorker :public FRunnable
{

private:

	//Thread
	FRunnableThread* Thread;

	//Pointer to our manager
	AMySpeechActor* Manager;

	FThreadSafeCounter StopTaskCounter;

	FWhisperParams params;
public:
	FMySpeechWorker();
	virtual ~FMySpeechWorker();

	//FRunnable interface
	virtual void Stop();
	virtual uint32 Run();

	bool StartThread(AMySpeechActor* manager, FWhisperParams whisperParams);

	static void ClientMessage(FString txt);

	void ShutDown();

	//FWhisper_params params;

	void high_pass_filter(std::vector<float>& data, float cutoff, float sample_rate);

	bool vad_simple(std::vector<float>& pcmf32, int sample_rate, int last_ms, float vad_thold, float freq_thold, bool verbose);
};

