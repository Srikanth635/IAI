// Copyright 2020, Institute for Artificial Intelligence - University of Bremen
// Author: Jose Rojas

#include "ROSProlog/SLQueryHandler.h"

